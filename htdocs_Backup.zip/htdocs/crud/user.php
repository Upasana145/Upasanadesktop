<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <h1>Hello, world!</h1>
    <div class="container">
    <form method = "post">




  <div class="mb-3">
    <label >Name</label>
    <input style="width: 40%" type="text" class="form-control" placeholder = "Enter your name">
</div>




<div>
<label>Name </label>
<input type="text" placeholder = "enter your name" class="form-control" style = "width:40%">


</div>











<div class="mb-3">
    <label >Email</label>
    <input style="width: 40%" type="email" class="form-control" placeholder = "Enter your email">
</div>


<div class="mb-3">
    <label >Address </label>
    <input style="width: 40%" type="text" class="form-control" placeholder = "Enter your name">
</div>




<div class="mb-3">
<label for="phone">Enter your phone number:</label>
<input type="tel" style="width: 40%" id="phone" placeholder = "Enter your phone number" class="form-control" name="phone" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}">
</div>



<div class="mb-3">
<label for="phone">Enter your DOB</label>
<input type="date" style="width: 40%"  placeholder = "Enter your DOB" class="form-control" name="DOB">
</div>





<div class="row">
      <legend class="col-form-label col-sm-2 pt-0">Gender</legend>
      <div class="col-sm-10">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
          <label class="form-check-label" for="gridRadios1">
            Male
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
          <label class="form-check-label" for="gridRadios2">
            Female
          </label>
        </div>
      </div>
    </div>



 <div>
  <label class="my-1 mr-2" for="inlineFormCustomSelectPref">Caste</label>
     <select class="custom-select my-1 mr-sm-2">
      <option selected>Choose...</option>
      <option value="1">One</option>
      <option value="2">Two</option>
      <option value="3">Three</option>
    </select>
</div>



  <button type="submit" class="btn btn-primary">Submit</button>


</form>
    </div>

      </body>
</html>